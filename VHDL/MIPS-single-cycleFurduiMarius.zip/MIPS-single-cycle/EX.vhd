library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

entity EX is
    Port (
        rd1        : in  STD_LOGIC_VECTOR(31 downto 0);
        rd2        : in  STD_LOGIC_VECTOR(31 downto 0);
        ext_imm    : in  STD_LOGIC_VECTOR(31 downto 0);
        pc4        : in  STD_LOGIC_VECTOR(31 downto 0);
        sa         : in  STD_LOGIC_VECTOR(4 downto 0);
        func       : in  STD_LOGIC_VECTOR(5 downto 0);
        ALUOp      : in  STD_LOGIC_VECTOR(1 downto 0);
        ALUSrc     : in  STD_LOGIC;
        opcode     : in  STD_LOGIC_VECTOR(5 downto 0);
        ALURes     : out STD_LOGIC_VECTOR(31 downto 0);
        BranchAddr : out STD_LOGIC_VECTOR(31 downto 0);
        Zero       : out STD_LOGIC
    );
end EX;

architecture Behavioral of EX is

    signal ALUCtrl : STD_LOGIC_VECTOR(2 downto 0);
    signal op2     : STD_LOGIC_VECTOR(31 downto 0);
    signal alu_res : STD_LOGIC_VECTOR(31 downto 0);

begin
    op2 <= ext_imm when ALUSrc = '1' else rd2;
    BranchAddr <= pc4 + (ext_imm(29 downto 0) & "00");

    process(ALUOp, func, opcode)
    begin
        case ALUOp is
            when "00" =>
                ALUCtrl <= "010";

            when "01" =>
                ALUCtrl <= "110";

            when "10" =>
                case func is
                    when "100000" => ALUCtrl <= "010"; -- ADD
                    when "100010" => ALUCtrl <= "110"; -- SUB
                    when "101010" => ALUCtrl <= "111"; -- SLT
                    when "100110" => ALUCtrl <= "011"; -- XOR
                    when "100100" => ALUCtrl <= "000"; -- AND
                    when "100101" => ALUCtrl <= "001"; -- OR
                    when "000000" => ALUCtrl <= "100"; -- SLL
                    when "000010" => ALUCtrl <= "101"; -- SRL
                    when others   => ALUCtrl <= "010";
                end case;

            when "11" =>
                case opcode is
                    when "001010" => ALUCtrl <= "111"; -- SLTI
                    when "001100" => ALUCtrl <= "000"; -- ANDI
                    when "001101" => ALUCtrl <= "001"; -- ORI
                    when others   => ALUCtrl <= "010";
                end case;

            when others => ALUCtrl <= "010";
        end case;
    end process;

    process(ALUCtrl, rd1, op2, sa)
    begin
        case ALUCtrl is

            when "010" =>   -- ADD
                alu_res <= rd1 + op2;

            when "110" =>   -- SUB
                alu_res <= rd1 - op2;

            when "000" =>   -- AND
                alu_res <= rd1 and op2;

            when "001" =>   -- OR
                alu_res <= rd1 or op2;

            when "011" =>   -- XOR
                alu_res <= rd1 xor op2;

            when "100" =>   -- SLL
                alu_res <= to_stdlogicvector(
                    to_bitvector(op2) sll conv_integer(sa));

            when "101" =>   -- SRL
                alu_res <= to_stdlogicvector(
                    to_bitvector(op2) srl conv_integer(sa));

            when "111" =>   -- SLT
                if conv_integer(rd1) < conv_integer(op2) then
                    alu_res <= X"00000001";
                else
                    alu_res <= X"00000000";
                end if;

            when others =>
                alu_res <= X"00000000";
        end case;
    end process;

    Zero   <= '1' when alu_res = X"00000000" else '0';
    ALURes <= alu_res;

end Behavioral;
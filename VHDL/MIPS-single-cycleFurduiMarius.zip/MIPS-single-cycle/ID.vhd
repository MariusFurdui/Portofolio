library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity ID is
    Port (
        clk   : in  STD_LOGIC;
        RegWr : in  STD_LOGIC;
        en    : in  STD_LOGIC;
        ra1   : in  STD_LOGIC_VECTOR(4 downto 0);
        ra2   : in  STD_LOGIC_VECTOR(4 downto 0);
        wa    : in  STD_LOGIC_VECTOR(4 downto 0);
        wd    : in  STD_LOGIC_VECTOR(31 downto 0);
        rd1   : out STD_LOGIC_VECTOR(31 downto 0);
        rd2   : out STD_LOGIC_VECTOR(31 downto 0)
    );
end ID;

architecture Behavioral of ID is
    type rf_type is array(0 to 31) of STD_LOGIC_VECTOR(31 downto 0);
    signal rf : rf_type := (
        others => X"00000000"
    );
begin
    rd1 <= rf(to_integer(unsigned(ra1)));
    rd2 <= rf(to_integer(unsigned(ra2)));

    process(clk)
    begin
        if rising_edge(clk) then
            if en = '1' and RegWr = '1' then
                if wa /= "00000" then
                    rf(to_integer(unsigned(wa))) <= wd;
                end if;
            end if;
        end if;
    end process;
end Behavioral;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity UC is
    Port (
        opcode   : in  STD_LOGIC_VECTOR(5 downto 0);
        RegDst   : out STD_LOGIC;
        ExtOp    : out STD_LOGIC;
        ALUSrc   : out STD_LOGIC;
        Branch   : out STD_LOGIC;
        Jump     : out STD_LOGIC;
        ALUOp    : out STD_LOGIC_VECTOR(1 downto 0);
        MemWrite : out STD_LOGIC;
        RegWrite : out STD_LOGIC;
        MemtoReg : out STD_LOGIC
    );
end UC;

architecture Behavioral of UC is
begin
    process(opcode)
    begin
        -- default
        RegDst   <= '0';
        ExtOp    <= '0';
        ALUSrc   <= '0';
        Branch   <= '0';
        Jump     <= '0';
        ALUOp    <= "00";
        MemWrite <= '0';
        RegWrite <= '0';
        MemtoReg <= '0';

        case opcode is

            -- TIP R (add, sub, slt, xor, and, or, sll, srl)
            when "000000" =>
                RegDst   <= '1';
                RegWrite <= '1';
                ALUOp    <= "10";

            -- ADDI
            when "001000" =>
                ExtOp    <= '1';
                ALUSrc   <= '1';
                RegWrite <= '1';
                ALUOp    <= "00";

            -- SLTI
            when "001010" =>
                ExtOp    <= '1';
                ALUSrc   <= '1';
                RegWrite <= '1';
                ALUOp    <= "11";

            -- ANDI
            when "001100" =>
                ALUSrc   <= '1';
                RegWrite <= '1';
                ALUOp    <= "11";

            -- ORI
            when "001101" =>
                ALUSrc   <= '1';
                RegWrite <= '1';
                ALUOp    <= "11";

            -- LW
            when "100011" =>
                ExtOp    <= '1';
                ALUSrc   <= '1';
                RegWrite <= '1';
                MemtoReg <= '1';
                ALUOp    <= "00";

            -- SW
            when "101011" =>
                ExtOp    <= '1';
                ALUSrc   <= '1';
                MemWrite <= '1';
                ALUOp    <= "00";

            -- BEQ
            when "000100" =>
                ExtOp    <= '1';
                Branch   <= '1';
                ALUOp    <= "01";

            -- BNE
            when "000101" =>
                ExtOp    <= '1';
                Branch   <= '1';
                ALUOp    <= "01";

            -- J
            when "000010" =>
                Jump     <= '1';

            when others => null;
        end case;
    end process;
end Behavioral;
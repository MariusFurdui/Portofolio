library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity MEM is
    Port (
        clk       : in  STD_LOGIC;
        en        : in  STD_LOGIC;
        MemWrite  : in  STD_LOGIC;
        ALUResIn  : in  STD_LOGIC_VECTOR(31 downto 0);
        RD2       : in  STD_LOGIC_VECTOR(31 downto 0);
        MemData   : out STD_LOGIC_VECTOR(31 downto 0);
        ALUResOut : out STD_LOGIC_VECTOR(31 downto 0)
    );
end MEM;

architecture Behavioral of MEM is

    type ram_type is array(0 to 63) of STD_LOGIC_VECTOR(31 downto 0);
    signal mem : ram_type := (
        -- adresa 0: rezultat (initial 0)
        0      => X"00000000", 
        -- adresa 4: N = 5 elemente
        1      => X"00000005", 
        -- adresa 8: elemente sir (5, -2, 3, 0, 7)
        2      => X"00000005",  -- pozitiv impar
        3      => X"FFFFFFFE",  -- negativ (-2)
        4      => X"00000003",  -- pozitiv impar
        5      => X"00000000",  -- zero (nu e pozitiv)
        6      => X"00000007",  -- pozitiv impar
        others => X"00000000"
    );

    signal addr : STD_LOGIC_VECTOR(5 downto 0);

begin

    addr <= ALUResIn(7 downto 2);

    process(clk)
    begin
        if rising_edge(clk) then
            if en = '1' and MemWrite = '1' then
                mem(conv_integer(addr)) <= RD2;
            end if;
        end if;
    end process;

    MemData   <= mem(conv_integer(addr));
    ALUResOut <= ALUResIn;

end Behavioral;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity IFetch is
    Port (
        clk         : in  STD_LOGIC;
        rst         : in  STD_LOGIC;
        en          : in  STD_LOGIC;
        Jump        : in  STD_LOGIC;
        PCSrc       : in  STD_LOGIC;
        JmpR        : in  STD_LOGIC;
        instruction : out STD_LOGIC_VECTOR(31 downto 0);
        pc_plus4    : out STD_LOGIC_VECTOR(31 downto 0);
        JumpAddr   : in STD_LOGIC_VECTOR(31 downto 0);
        BranchAddr : in STD_LOGIC_VECTOR(31 downto 0)
    );
end IFetch;

architecture Behavioral of IFetch is

    type rom_type is array (0 to 31) of STD_LOGIC_VECTOR(31 downto 0);
    constant ROM_32x32 : rom_type := (
        0  => B"100011_00000_01010_0000000000000100",
        -- 0x8C0A0004 ; 0   ; lw $t2, 4($zero)       ; $t2 = MEM[0+4] = 5 (N=numarul de elemente)

        1  => B"001000_00000_01001_0000000000000000",
        -- 0x20090000 ; 1   ; addi $t1, $zero, 0     ; $t1 = 0 (contor elemente parcurse)

        2  => B"001000_00000_01011_0000000000001000",
        -- 0x200B0008 ; 2   ; addi $t3, $zero, 8     ; $t3 = 8 (adresa primului element)

        3  => B"001000_00000_01000_0000000000000000",
        -- 0x20080000 ; 3   ; addi $t0, $zero, 0     ; $t0 = 0 (contor valori pozitive si impare)

        4  => B"000100_01001_01010_0000000000001001",
        -- 0x112A0009 ; 4   ; beq $t1, $t2, 9        ; daca $t1==$t2 sare la poz.14 (final)

        5  => B"100011_01011_01100_0000000000000000",
        -- 0x8D6C0000 ; 5   ; lw $t4, 0($t3)         ; $t4 = MEM[$t3] (element curent din sir)

        6  => B"000000_00000_01100_00101_00000_101010",
        -- 0x0004682A ; 6   ; slt $t5, $zero, $t4    ; $t5 = 1 daca $t4 > 0 (pozitiv)

        7  => B"000101_01101_00000_0000000000000011",
        -- 0x15A00003 ; 7   ; bne $t5, $zero, 3      ; daca $t5!=0 sare la poz.11 (e pozitiv)

        8  => B"001100_01100_01101_0000000000000001",
        -- 0x318D0001 ; 8   ; andi $t5, $t4, 1       ; $t5 = $t4 AND 1 (test bit LSB pentru impar)

        9  => B"000100_01101_00000_0000000000000001",
        -- 0x11A00001 ; 9   ; beq $t5, $zero, 1      ; daca $t5==0 sare la poz.11 (e par, nu numara)

        10 => B"001000_01000_01000_0000000000000001",
        -- 0x21080001 ; 10  ; addi $t0, $t0, 1       ; $t0++ (e pozitiv SI impar, incrementam)

        11 => B"001000_01001_01001_0000000000000001",
        -- 0x21290001 ; 11  ; addi $t1, $t1, 1       ; $t1++ (am parcurs un element)

        12 => B"001000_01011_01011_0000000000000100",
        -- 0x216B0004 ; 12  ; addi $t3, $t3, 4       ; $t3 += 4 (adresa urmatorului element)

        13 => B"000010_00000000000000000000000100",
        -- 0x08000004 ; 13  ; j 4                    ; sare inapoi la testul de terminare bucla

        14 => B"101011_00000_01000_0000000000000000",
        -- 0xAC080000 ; 14  ; sw $t0, 0($zero)       ; MEM[0] = $t0 (salveaza rezultatul)

        15 => B"000010_00000000000000000000001111",
        -- 0x0800000F ; 15  ; j 15                   ; bucla infinita (program terminat)
        others => X"00000000"
    );

    

    signal PC       : STD_LOGIC_VECTOR(31 downto 0) := (others => '0');
    signal PC4      : STD_LOGIC_VECTOR(31 downto 0);
    signal PC_next  : STD_LOGIC_VECTOR(31 downto 0);
    signal rom_addr : STD_LOGIC_VECTOR(4 downto 0);

begin

    PC4 <= STD_LOGIC_VECTOR(unsigned(PC) + 4);

    PC_next <= JumpAddr   when Jump   = '1' else
               BranchAddr when PCSrc  = '1' else
               PC4;

    process(clk, rst)
    begin
        if rst = '1' then
            PC <= (others => '0');
        elsif rising_edge(clk) then
            if en = '1' then
                PC <= PC_next;
            end if;
        end if;
    end process;

    rom_addr <= PC(6 downto 2);

    instruction <= ROM_32x32(to_integer(unsigned(rom_addr)));
    pc_plus4    <= PC4;

end Behavioral;

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity SSD is
    Port (
        clk     : in  STD_LOGIC;
        digits  : in  STD_LOGIC_VECTOR(31 downto 0);
        an      : out STD_LOGIC_VECTOR(7 downto 0);
        cat     : out STD_LOGIC_VECTOR(6 downto 0)
    );
end SSD;

architecture Behavioral of SSD is

    signal counter : STD_LOGIC_VECTOR(16 downto 0) := (others => '0');
    signal sel : STD_LOGIC_VECTOR(2 downto 0);
    signal hex : STD_LOGIC_VECTOR(3 downto 0);

begin

    process(clk)
    begin
        if rising_edge(clk) then
            counter <= counter + 1;
        end if;
    end process;
    
    sel <= counter(16 downto 14);
    
    with sel select
        hex <= digits(31 downto 28) when "000",  
               digits(27 downto 24) when "001",  
               digits(23 downto 20) when "010",  
               digits(19 downto 16) when "011",  
               digits(15 downto 12) when "100",  
               digits(11 downto 8)  when "101",
               digits(7 downto 4)   when "110",  
               digits(3 downto 0)   when others; 
    
    with hex select
        cat <= "1000000" when "0000",  -- 0
               "1111001" when "0001",  -- 1
               "0100100" when "0010",  -- 2
               "0110000" when "0011",  -- 3
               "0011001" when "0100",  -- 4
               "0010010" when "0101",  -- 5
               "0000010" when "0110",  -- 6
               "1111000" when "0111",  -- 7
               "0000000" when "1000",  -- 8
               "0010000" when "1001",  -- 9
               "0001000" when "1010",  -- A
               "0000011" when "1011",  -- B
               "1000110" when "1100",  -- C
               "0100001" when "1101",  -- D
               "0000110" when "1110",  -- E
               "0001110" when others;  -- F
    
    with sel select
        an <= "01111111" when "000",   
              "10111111" when "001",  
              "11011111" when "010",   
              "11101111" when "011",   
              "11110111" when "100",   
              "11111011" when "101",
              "11111101" when "110",   
              "11111110" when others;  

end Behavioral;
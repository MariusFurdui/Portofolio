library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity test_env is
    Port (
        clk : in  STD_LOGIC;
        btn : in  STD_LOGIC_VECTOR(4 downto 0);
        sw  : in  STD_LOGIC_VECTOR(15 downto 0);
        led : out STD_LOGIC_VECTOR(15 downto 0);
        an  : out STD_LOGIC_VECTOR(7 downto 0);
        cat : out STD_LOGIC_VECTOR(6 downto 0)
    );
end test_env;

architecture Behavioral of test_env is

    component MPG is
        Port (
            btn    : in  STD_LOGIC;
            clk    : in  STD_LOGIC;
            enable : out STD_LOGIC
        );
    end component;

    component SSD is
        Port (
            clk    : in  STD_LOGIC;
            digits : in  STD_LOGIC_VECTOR(31 downto 0);
            an     : out STD_LOGIC_VECTOR(7 downto 0);
            cat    : out STD_LOGIC_VECTOR(6 downto 0)
        );
    end component;

    component IFetch is
        Port (
            clk         : in  STD_LOGIC;
            rst         : in  STD_LOGIC;
            en          : in  STD_LOGIC;
            Jump        : in  STD_LOGIC;
            PCSrc       : in  STD_LOGIC;
            JmpR        : in  STD_LOGIC;
            JumpAddr    : in  STD_LOGIC_VECTOR(31 downto 0);
            BranchAddr  : in  STD_LOGIC_VECTOR(31 downto 0);
            instruction : out STD_LOGIC_VECTOR(31 downto 0);
            pc_plus4    : out STD_LOGIC_VECTOR(31 downto 0)
        );
    end component;

    component UC is
        Port (
            opcode   : in  STD_LOGIC_VECTOR(5 downto 0);
            RegDst   : out STD_LOGIC;
            ExtOp    : out STD_LOGIC;
            ALUSrc   : out STD_LOGIC;
            Branch   : out STD_LOGIC;
            Jump     : out STD_LOGIC;
            ALUOp    : out STD_LOGIC_VECTOR(1 downto 0);
            MemWrite : out STD_LOGIC;
            RegWrite : out STD_LOGIC;
            MemtoReg : out STD_LOGIC
        );
    end component;

    component ID is
        Port (
            clk   : in  STD_LOGIC;
            RegWr : in  STD_LOGIC;
            en    : in  STD_LOGIC;
            ra1   : in  STD_LOGIC_VECTOR(4 downto 0);
            ra2   : in  STD_LOGIC_VECTOR(4 downto 0);
            wa    : in  STD_LOGIC_VECTOR(4 downto 0);
            wd    : in  STD_LOGIC_VECTOR(31 downto 0);
            rd1   : out STD_LOGIC_VECTOR(31 downto 0);
            rd2   : out STD_LOGIC_VECTOR(31 downto 0)
        );
    end component;

    component EX is
        Port (
            rd1        : in  STD_LOGIC_VECTOR(31 downto 0);
            rd2        : in  STD_LOGIC_VECTOR(31 downto 0);
            ext_imm    : in  STD_LOGIC_VECTOR(31 downto 0);
            pc4        : in  STD_LOGIC_VECTOR(31 downto 0);
            sa         : in  STD_LOGIC_VECTOR(4 downto 0);
            func       : in  STD_LOGIC_VECTOR(5 downto 0);
            ALUOp      : in  STD_LOGIC_VECTOR(1 downto 0);
            ALUSrc     : in  STD_LOGIC;
            opcode     : in  STD_LOGIC_VECTOR(5 downto 0);
            ALURes     : out STD_LOGIC_VECTOR(31 downto 0);
            BranchAddr : out STD_LOGIC_VECTOR(31 downto 0);
            Zero       : out STD_LOGIC
        );
    end component;

    component MEM is
        Port (
            clk       : in  STD_LOGIC;
            en        : in  STD_LOGIC;
            MemWrite  : in  STD_LOGIC;
            ALUResIn  : in  STD_LOGIC_VECTOR(31 downto 0);
            RD2       : in  STD_LOGIC_VECTOR(31 downto 0);
            MemData   : out STD_LOGIC_VECTOR(31 downto 0);
            ALUResOut : out STD_LOGIC_VECTOR(31 downto 0)
        );
    end component;

    signal enable      : STD_LOGIC;

    signal instr       : STD_LOGIC_VECTOR(31 downto 0);
    signal pc4         : STD_LOGIC_VECTOR(31 downto 0);

    signal s_RegDst    : STD_LOGIC;
    signal s_ExtOp     : STD_LOGIC;
    signal s_ALUSrc    : STD_LOGIC;
    signal s_Branch    : STD_LOGIC;
    signal s_Jump      : STD_LOGIC;
    signal s_ALUOp     : STD_LOGIC_VECTOR(1 downto 0);
    signal s_MemWrite  : STD_LOGIC;
    signal s_RegWrite  : STD_LOGIC;
    signal s_MemtoReg  : STD_LOGIC;

    signal s_wa        : STD_LOGIC_VECTOR(4 downto 0);
    signal s_rd1       : STD_LOGIC_VECTOR(31 downto 0);
    signal s_rd2       : STD_LOGIC_VECTOR(31 downto 0);
    signal s_wd        : STD_LOGIC_VECTOR(31 downto 0);
    signal s_ext_imm   : STD_LOGIC_VECTOR(31 downto 0);
    signal s_func      : STD_LOGIC_VECTOR(5 downto 0);
    signal s_sa        : STD_LOGIC_VECTOR(4 downto 0);

    signal s_ALURes    : STD_LOGIC_VECTOR(31 downto 0);
    signal s_BranchAddr: STD_LOGIC_VECTOR(31 downto 0);
    signal s_Zero      : STD_LOGIC;
    signal s_PCSrc     : STD_LOGIC;
    signal s_JumpAddr  : STD_LOGIC_VECTOR(31 downto 0);

    signal s_MemData   : STD_LOGIC_VECTOR(31 downto 0);
    signal s_ALUResOut : STD_LOGIC_VECTOR(31 downto 0);

    signal ssd_digits  : STD_LOGIC_VECTOR(31 downto 0);
    
    signal s_isBNE : STD_LOGIC;

begin

    MPG_inst: MPG port map (
        btn    => btn(0),
        clk    => clk,
        enable => enable
    );

    IFetch_inst: IFetch port map (
        clk         => clk,
        rst         => btn(1),
        en          => enable,
        Jump        => s_Jump,
        PCSrc       => s_PCSrc,
        JmpR        => '0',
        JumpAddr    => s_JumpAddr,
        BranchAddr  => s_BranchAddr,
        instruction => instr,
        pc_plus4    => pc4
    );

    UC_inst: UC port map (
        opcode   => instr(31 downto 26),
        RegDst   => s_RegDst,
        ExtOp    => s_ExtOp,
        ALUSrc   => s_ALUSrc,
        Branch   => s_Branch,
        Jump     => s_Jump,
        ALUOp    => s_ALUOp,
        MemWrite => s_MemWrite,
        RegWrite => s_RegWrite,
        MemtoReg => s_MemtoReg
    );

    s_wa <= instr(15 downto 11) when s_RegDst = '1'
       else instr(20 downto 16);

    s_ext_imm(15 downto 0)  <= instr(15 downto 0);
    s_ext_imm(31 downto 16) <= (others => instr(15)) when s_ExtOp = '1'
                           else (others => '0');

    s_func <= instr(5 downto 0);
    s_sa   <= instr(10 downto 6);

    ID_inst: ID port map (
        clk   => clk,
        RegWr => s_RegWrite,
        en    => enable,
        ra1   => instr(25 downto 21),
        ra2   => instr(20 downto 16),
        wa    => s_wa,
        wd    => s_wd,
        rd1   => s_rd1,
        rd2   => s_rd2
    );

    EX_inst: EX port map (
        rd1        => s_rd1,
        rd2        => s_rd2,
        ext_imm    => s_ext_imm,
        pc4        => pc4,
        sa         => s_sa,
        func       => s_func,
        ALUOp      => s_ALUOp,
        ALUSrc     => s_ALUSrc,
        opcode     => instr(31 downto 26),
        ALURes     => s_ALURes,
        BranchAddr => s_BranchAddr,
        Zero       => s_Zero
    );
    
    s_isBNE <= '1' when instr(31 downto 26) = "000101" else '0';
    s_PCSrc    <= (s_Branch and s_Zero and (not s_isBNE)) or 
    (s_Branch and (not s_Zero) and s_isBNE);
    s_JumpAddr <= pc4(31 downto 28) & instr(25 downto 0) & "00";

    MEM_inst: MEM port map (
        clk       => clk,
        en        => enable,
        MemWrite  => s_MemWrite,
        ALUResIn  => s_ALURes,
        RD2       => s_rd2,
        MemData   => s_MemData,
        ALUResOut => s_ALUResOut
    );

    s_wd <= s_MemData when s_MemtoReg = '1' else s_ALUResOut;

    process(sw, instr, pc4, s_rd1, s_rd2, s_wd,
            s_ext_imm, s_ALURes, s_MemData)
    begin
        case sw(7 downto 5) is
            when "000"  => ssd_digits <= instr;
            when "001"  => ssd_digits <= pc4;
            when "010"  => ssd_digits <= s_rd1;
            when "011"  => ssd_digits <= s_rd2;
            when "100"  => ssd_digits <= s_ext_imm;
            when "101"  => ssd_digits <= s_ALURes;
            when "110"  => ssd_digits <= s_MemData;
            when others => ssd_digits <= s_wd;
        end case;
    end process;

    SSD_inst: SSD port map (
        clk    => clk,
        digits => ssd_digits,
        an     => an,
        cat    => cat
    );

    led(0)            <= s_RegDst;
    led(1)            <= s_ExtOp;
    led(2)            <= s_ALUSrc;
    led(3)            <= s_Branch;
    led(4)            <= s_Jump;
    led(5)            <= s_MemWrite;
    led(6)            <= s_RegWrite;
    led(7)            <= s_MemtoReg;
    led(9 downto 8)   <= s_ALUOp;
    led(10)           <= s_Zero;
    led(11)           <= s_PCSrc;
    led(15 downto 12) <= (others => '0');

end Behavioral;

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity MPG is
    Port ( btn : in STD_LOGIC;
           clk : in STD_LOGIC;
           enable : out STD_LOGIC);
end MPG;

architecture Behavioral of MPG is

signal counter : STD_LOGIC_VECTOR(15 downto 0) := (others => '0');
signal Q1 : STD_LOGIC;
signal Q2 : STD_LOGIC;
signal Q3 : STD_LOGIC;

begin

    process(clk)
    begin
        if rising_edge(clk) then
            counter <= counter + 1;
        end if;
    end process;

    process(clk)
    begin
        if rising_edge(clk) then
            if counter = x"FFFF" then
                Q1 <= btn;
            end if;
        end if;
    end process;

    process(clk)
    begin
        if rising_edge(clk) then
            Q2 <= Q1;
        end if;
    end process;

    process(clk)
    begin
        if rising_edge(clk) then
            Q3 <= Q2;
        end if;
    end process;

    enable <= Q2 and not Q3;

end Behavioral;
